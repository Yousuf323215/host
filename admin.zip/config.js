//By Pak Toya
const global = {
    owner: [7116091245], // ganti jadi id mu
    botToken: "7764529762:AAFNnEfw7jDzok6DQNGHwVaysjzi1pNQc7M", //isi make token bot mu
}

module.exports = global;